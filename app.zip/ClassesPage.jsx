import React, { useState, useEffect } from 'react';
import {
  View,
  TextInput,
  Button,
  FlatList,
  Text,
  StyleSheet,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
  ActivityIndicator
} from 'react-native';
import axios from 'axios';
import { useRoute } from '@react-navigation/native';
import FooterNav from './FooterNav';

const API_BASE = 'http://127.0.0.1:8000';

export default function ClassesPage() {
  const route = useRoute();
  const user = route.params?.user;

  const [search, setSearch] = useState('');
  const [classes, setClasses] = useState([]);
  const [newName, setNewName] = useState('');
  const [newMax, setNewMax] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchClasses = () => {
    setLoading(true);
    axios.get(`${API_BASE}/classes/`, { params: { search } })
      .then(res => setClasses(res.data))
      .catch(() => Alert.alert('Errore', 'Impossibile caricare le classi'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    console.log("user:", user);
    fetchClasses();
  }, [search]);

  const handleCreate = () => {
  if (!newName || !newMax) {
    Alert.alert('Errore', 'Inserisci nome e numero partecipanti');
    return;
  }
  if (!user || !user.id) {
    Alert.alert('Errore', 'Utente non autenticato');
    return;
  }

  const payload = {
    name: newName.trim(),
    max_participants: parseInt(newMax, 10),
    admin_id: Number(user.id),
  };

  console.log("Payload inviato:", payload);

  axios.post(`${API_BASE}/classes/`, payload)
    .then(res => {
      Alert.alert('Successo', 'Classe creata');
      setNewName('');
      setNewMax('');
      fetchClasses();
    })
    .catch(err => {
      console.error("Errore POST:", err);
      if (err.response) {
        console.error("Dettaglio:", err.response.data);
        Alert.alert("Errore", err.response.data.detail || "Errore nella creazione");
      } else {
        Alert.alert("Errore", "Errore di rete");
      }
    });
};


  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <TextInput
            style={styles.search}
            placeholder="Cerca classe..."
            value={search}
            onChangeText={setSearch}
          />

          {loading ? (
            <ActivityIndicator size="large" color="#0000ff" />
          ) : (
            <FlatList
              data={classes}
              keyExtractor={item => item.id.toString()}
              renderItem={({ item }) => (
                <Text style={styles.item}>
                  {item.name} ({item.max_participants})
                </Text>
              )}
              ListEmptyComponent={
                <Text style={styles.emptyText}>Nessuna classe trovata</Text>
              }
            />
          )}

          <TextInput
            style={styles.input}
            placeholder="Nome nuova classe"
            value={newName}
            onChangeText={setNewName}
          />
          <TextInput
            style={styles.input}
            placeholder="Numero partecipanti"
            keyboardType="numeric"
            value={newMax}
            onChangeText={setNewMax}
          />
          <View style={styles.buttonContainer}>
            <Button title="Crea Classe" onPress={handleCreate} />
          </View>

          {/* Spazio per non coprire il contenuto con la navbar */}
          <View style={{ height: 80 }} />
        </ScrollView>

        <FooterNav />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f0f0f5',
    flexGrow: 1
  },
  search: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    marginBottom: 10,
    borderRadius: 8,
    backgroundColor: '#fff'
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#eee'
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#666'
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    marginTop: 10,
    borderRadius: 8,
    backgroundColor: '#fff'
  },
  buttonContainer: {
    marginTop: 10
  }
});
