// index.js

// Importa i moduli necessari
const express = require("express");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const cors = require("cors");

// Carica le variabili d'ambiente
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Connetti al database MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on("connected", () => {
  console.log("✅ Connesso a MongoDB");
});

mongoose.connection.on("error", (err) => {
  console.error("❌ Errore di connessione a MongoDB:", err);
});

// Rotta di test
app.get("/", (req, res) => {
  res.send("Benvenuto su SchoolBet API!");
});

// Avvia il server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server in esecuzione sulla porta ${PORT}`);
});
